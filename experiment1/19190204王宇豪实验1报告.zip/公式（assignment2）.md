$$
Y = 0.299 \times R +0.587\times G+0.144 \times B
$$

$$
I=\frac{1}{3} (R+G+B)
$$

$Y,I\in[0,255]$



